package com.utcn.demo.controller;

import com.utcn.demo.entity.Person;
import com.utcn.demo.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/person")
public class PersonController {
    @Autowired
    private PersonService personService;

    @GetMapping("/person")
    public List<Person> getPersons() {
        return personService.findAll();
    }

    @PostMapping("/person")
    public Person addPerson(@RequestBody Person person) {
        return personService.save(person);
    }
}
