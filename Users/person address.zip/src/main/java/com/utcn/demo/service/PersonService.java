package com.utcn.demo.service;

import com.utcn.demo.entity.Person;
import com.utcn.demo.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class PersonService {

    @Autowired
    private PersonRepository personRepository;

    public List<Person> findAll() {
        List<Person> people = (List<Person>) this.personRepository.findAll();
        return people;
    }

    public Person findById(int id) {
        Optional<Person> person = personRepository.findById(Long.valueOf(id));
        if (person.isPresent()) {
            return person.get();
        }
        return null;
    }

    public Person findById2(int id) {
        Optional<Person> person = personRepository.findById(Long.valueOf(id));
        return person.orElse(null);
    }

    public Person save(Person person) {
        return this.personRepository.save(person);
    }

    public void delete(Person person) {
        personRepository.delete(person);
    }

}
